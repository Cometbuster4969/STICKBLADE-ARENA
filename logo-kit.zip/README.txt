STICKBLADE ARENA — logo kit
===========================
transparent/  stickblade-arena-mark-transparent.png — keyed emblem, transparent BG.
              Use on hero sections, thumbnails, video, merch mockups.
favicons/     favicon.ico (16/32/48 multi-res), favicon-16x16.png,
              favicon-32x32.png, apple-touch-icon.png (180),
              android-chrome-192x192.png, android-chrome-512x512.png,
              mark-square-1024.png (transparent avatar/profile master).
              Icons use a flat warm-charcoal base for crisp tiny sizes.
lockup/       horizontal + stacked emblem+wordmark, transparent BG.
              For README headers, social banners, decks, video intros.
social/       og-image.png (1200x630) — link-preview card.
              Wire as og:image / twitter:image on the site.
_qa_*.png     quality-check sheets (magenta = transparency holes, white =
              edge fringe). Not for publishing; safe to delete.

Fonts: Bebas Neue (SIL Open Font License 1.1, free for commercial use),
DejaVu Sans (bundled, permissive). Brand orange ~ #FF711F on #0D0B09.
